Websites Used:
Animate On Scroll Library - https://michalsnik.github.io/aos/

Spline- https://app.spline.design/community

